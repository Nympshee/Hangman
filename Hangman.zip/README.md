# Hangman
Jogo da forca com interface ( C++ )
Feito por Pierina Alarcón Chamarelli e Goossens